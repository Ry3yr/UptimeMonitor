#!/bin/sh

USER="admin"
PASS="passeria"
HOST="ftp.alcea-wisteria.de"
REMOTE_DIR="PHP/0demo/2025-08-04-UptimeCheck"
LOCAL_DIR="/storage/emulated/0/pws/www/2025-08-04-UptimeCheck"

# Upload each file using the curl in /system_ext/xbin
/system_ext/xbin/curl -T "$LOCAL_DIR/alceawis.com.json" "ftp://$USER:$PASS@$HOST/$REMOTE_DIR/alceawis.com.json"
/system_ext/xbin/curl -T "$LOCAL_DIR/alceawis.de.json" "ftp://$USER:$PASS@$HOST/$REMOTE_DIR/alceawis.de.json"
/system_ext/xbin/curl -T "$LOCAL_DIR/alcea-wisteria.de.json" "ftp://$USER:$PASS@$HOST/$REMOTE_DIR/alcea-wisteria.de.json"
